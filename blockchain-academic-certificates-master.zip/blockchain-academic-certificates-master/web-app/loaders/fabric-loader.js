let enrollment = require("../services/fabric/enrollment");

enrollment.enrollAdmin();